function [ r ] = residual( param, x0, u, t,XData, sigmaData)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here


end

