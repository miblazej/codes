% Author: Michal Blazej,Mohamed Emara,Juanito Sebestian Diaz
%% Data load and assigment to variables
clc;clear variables;
load('ex9_robotData.mat');
load('ex9_windData.mat');
% I assume that first column is a velocity of left wheel and second of
% right
omegaL=u(:,1);
omegaR=u(:,2);
% I assume that first column is a x position and second is y
x_pos=xy_meas(:,1);
y_pos=xy_meas(:,2);
% Declaration of known variances in x and y planes
variance_x = 1.6 * 10^(-3);
variance_y = 4 * 10^(-4);
sigmaData=[variance_x,variance_y];
%% Implementation of function residual
% Declaration of parameters variable
Rr=0;Rl=0;L=0;
param=[Rr,Rl,L];
% Declaration of initial position of robot
x_0=0;y_0=0;beta_0=0;
x0=[x_0,y_0,beta_0];
% Declaration of tim vector
t=0:0.01:0.01*298;
